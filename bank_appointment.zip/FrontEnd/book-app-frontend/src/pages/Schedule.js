import React from 'react';
import CreateCustomer from '../components/CreateCustomer';
function Schedule() {
	return (
		<div>
			<CreateCustomer />
		</div>
	);
}

export default Schedule;
