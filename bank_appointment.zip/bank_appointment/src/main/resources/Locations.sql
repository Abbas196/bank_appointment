insert into Locations (zip,address) values (64093,"116 W South St, Warrensburg, MO");
insert into Locations (zip,address) values (64086,"1101 NW Innovation Parkway, Lee's Summit, MO");
insert into Locations (zip,address) values (64063,"890 E Langsford Rd, Lee's Summit, MO");
insert into Locations (zip,address) values (64014,"815 MO-7, Blue Springs, MO");
insert into Locations (zip,address) values (64055,"17820 East 39th St S Ste 101, Independence, MO");
insert into Locations (zip,address) values (64133,"9410B E State Rte 350, Raytown, MO");
insert into Locations (zip,address) values (66209,"4700 W 119th St, Leawood, KS");
insert into Locations (zip,address) values (64030,"12018 S U.S. 71 Hwy, Grandview, MO");